import { Component, AfterViewInit, ViewChild, ElementRef,Renderer2 } from '@angular/core';
import Chart from 'chart.js/auto';


@Component({
  selector: 'app-multi-chart',
  templateUrl: './multi-chart.component.html',
  styleUrls: ['./multi-chart.component.css']
})
export class MultiChartComponent implements AfterViewInit{


  public chart: any;

  @ViewChild('multiSeriesPieChartCanvas') multiSeriesPieChartCanvas!: ElementRef;
  
constructor(private renderer: Renderer2){}
 

  ngAfterViewInit(): void {
    this.createChart();
  }


  createChart(){

    const chartData = {
      labels: ['male', 'female'],
      datasets: [{
        data: [30, 40],
        backgroundColor: ['#F4D160', '#FBEEAC'],
       
      },

      {
        data: [20, 50,70],
        backgroundColor: ['#03C988', '#68B984','#50F306'],
       
      }
    ]
    };

    const chartOptions: any = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        datalabels: {
          formatter: (value: number, ctx: any) => {
            const datasets = ctx.chart.data.datasets;
            if (datasets.indexOf(ctx.dataset) === datasets.length - 1) {
              // Calculate the total sum of data for the current dataset
              const sum = datasets.reduce((acc:number, dataset:any) => {
                const datasetData = dataset.data as number[];
                return acc + datasetData.reduce((datasetSum, data) => datasetSum + data, 0);
              }, 0);
    
              // Calculate the percentage and format it as a string
              const percentage = ((value * 100) / sum).toFixed(0) + '%';
              return percentage;
            } else {
              return '';

            }
          },
          color: '#fff', // Color of the data labels
          anchor: 'end',
          align: 'end',
          offset: 4 // Distance between the data label and the chart
        }
      }
    };

    // Get the canvas element
    const canvas: HTMLCanvasElement = this.multiSeriesPieChartCanvas.nativeElement;
    const ctx: CanvasRenderingContext2D = canvas.getContext('2d')!;

 import('chartjs-plugin-datalabels').then((ChartDataLabels)=>{ 

    // Create the pie chart using Chart.js
    this.chart = new Chart(ctx, {
      type: 'pie',
      data: chartData,
      options: chartOptions,
      plugins: [ChartDataLabels.default] 
    });
  });

  
  }
  }




